let tasks = [];

let api = "https://jsonplaceholder.typicode.com/todos";


// Add Task
function addTask() {

    let task = document.getElementById("task").value;
    let priority = document.getElementById("priority").value;

    if (task == "") {
        alert("Enter a task");
        return;
    }

    let newTask = {
        title: task,
        priority: priority,
        completed: false
    };

    // API me data save
    fetch(api, {
        method: "POST",
        body: JSON.stringify(newTask),
        headers: {
            "Content-Type": "application/json"
        }
    })
    .then(response => response.json())
    .then(data => {

        tasks.push(data);

        showTasks(tasks);

        document.getElementById("task").value = "";

        alert("Task Added");

    });

}


// Show Tasks
function showTasks(list) {

    let ul = document.getElementById("taskList");

    ul.innerHTML = "";

    for (let i = 0; i < list.length; i++) {

        let li = document.createElement("li");

        li.innerHTML =
            "<input type='checkbox' onclick='completeTask(" + i + ")'>" +
            " " + list[i].title +
            " <span>" + list[i].priority + "</span>" +
            " <button onclick='deleteTask(" + i + ")'>Delete</button>";

        ul.appendChild(li);
    }

    document.getElementById("total").innerHTML = tasks.length;
}


// Complete
function completeTask(index) {

    tasks[index].completed = true;

    showTasks(tasks);
}


// Delete
function deleteTask(index) {

    tasks.splice(index, 1);

    showTasks(tasks);
}


// All Tasks
function allTasks() {

    document.getElementById("heading").innerHTML = "All Tasks";

    showTasks(tasks);
}


// Add Task
function addTaskPage() {

    document.getElementById("heading").innerHTML = "Add Task";

}


// Completed
function completedTasks() {

    document.getElementById("heading").innerHTML = "Completed Tasks";

    let completed = [];

    for (let i = 0; i < tasks.length; i++) {

        if (tasks[i].completed == true) {

            completed.push(tasks[i]);

        }
    }

    showTasks(completed);
}